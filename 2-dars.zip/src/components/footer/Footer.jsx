// style
import './Footer.css'


function Footer() {
  return (
    <div className='footer'>
     <div className='footer-container container'>
      <p>All Right Reserved. <a href="https://t.me/ozodbekweb">Мирзаахмадов</a></p>
     </div>
    </div>
  )
}

export default Footer;

